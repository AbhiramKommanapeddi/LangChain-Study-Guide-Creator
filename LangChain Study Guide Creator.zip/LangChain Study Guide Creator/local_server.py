#!/usr/bin/env python3
"""
Simple local server to view generated study guides
This fixes the white screen issue by serving content properly
"""

import http.server
import socketserver
import webbrowser
import os
import threading
import time

def start_local_server(port=8080):
    """Start a simple HTTP server to serve the generated content."""
    
    class CustomHandler(http.server.SimpleHTTPRequestHandler):
        def end_headers(self):
            self.send_header('Access-Control-Allow-Origin', '*')
            super().end_headers()
    
    try:
        with socketserver.TCPServer(("", port), CustomHandler) as httpd:
            print(f"🌐 Local server started at http://localhost:{port}")
            print(f"📁 Serving files from: {os.getcwd()}")
            print(f"🎯 Available study guides:")
            
            # List available study guides
            for folder in ['calculus_output', 'cell_biology_output', 'cs_output']:
                if os.path.exists(folder):
                    html_file = None
                    for file in os.listdir(folder):
                        if file.endswith('.html'):
                            html_file = file
                            break
                    if html_file:
                        print(f"   📚 {folder}: http://localhost:{port}/{folder}/{html_file}")
            
            print(f"🖥️  Demo viewer: http://localhost:{port}/demo_viewer.html")
            print(f"📊 Press Ctrl+C to stop the server")
            
            # Open browser after a short delay
            def open_browser():
                time.sleep(2)
                webbrowser.open(f'http://localhost:{port}/demo_viewer.html')
            
            browser_thread = threading.Thread(target=open_browser)
            browser_thread.daemon = True
            browser_thread.start()
            
            httpd.serve_forever()
            
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"❌ Port {port} is already in use. Trying port {port + 1}...")
            start_local_server(port + 1)
        else:
            print(f"❌ Error starting server: {e}")

if __name__ == "__main__":
    print("🚀 Starting Local Study Guide Viewer")
    print("=" * 50)
    start_local_server()
